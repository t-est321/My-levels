return {
  level_width = 400fx,
  level_height = 400fx
}