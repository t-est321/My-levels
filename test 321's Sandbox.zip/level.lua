local random_level = fmath.random_int(1,13)
local random_weapon = fmath.random_int(1,15)

local width = 750fx
local height = 750fx
pewpew.set_level_size(width, height)

local background = pewpew.new_customizable_entity(width / 750fx, height / 750fx)
pewpew.customizable_entity_set_mesh(background, "/dynamic/rectangles_graphic.lua", 0)
local bg = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(bg, "/dynamic/level_graphics.lua", 0)
local function random_position()
  return fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height)
end
pewpew.configure_player(0, {shield = 3, camera_distance = -350fx, camera_rotation_x_axis = fmath.tau() / -30fx})
local ship = pewpew.new_player_ship(width / 2fx, height / 2fx, 0)

if random_weapon == 1 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.SINGLE})
elseif random_weapon == 2 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_5, cannon = pewpew.CannonType.DOUBLE})
elseif random_weapon == 3 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_1, cannon = pewpew.CannonType.HEMISPHERE})
elseif random_weapon == 4 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_10, cannon = pewpew.CannonType.TRIPLE})
elseif random_weapon == 5 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_10, cannon = pewpew.CannonType.LASER})
elseif random_weapon == 6 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.SHOTGUN})
elseif random_weapon == 7 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_1, cannon = pewpew.CannonType.SHOTGUN})
elseif random_weapon == 8 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_15, cannon = pewpew.CannonType.TIC_TOC})
elseif random_weapon == 9 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_15, cannon = pewpew.CannonType.FOUR_DIRECTIONS})
elseif random_weapon == 10 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.TRIPLE})
elseif random_weapon == 11 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_15, cannon = pewpew.CannonType.DOUBLE_SWIPE})
elseif random_weapon == 12 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.DOUBLE_SWIPE})
elseif random_weapon == 13 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_5, cannon = pewpew.CannonType.LASER})
elseif random_weapon == 14 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.LASER})
elseif random_weapon == 15 then
  pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.FOUR_DIRECTIONS})
end

function clamp(v, min, max)
  return v
end
local time = 0
if random_level == 1 then
pewpew.configure_player_hud(0, {top_left_line = "#ffff00ffBafs#ffffffff fast"})
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
  if time %10 == 0 then
    local x, y = random_position()
    pewpew.new_baf(x,y,fmath.random_fixedpoint(0fx,fmath.tau()),15fx,-1)
  end
  if time %20 == 0 then
    local x, y = random_position()
    pewpew.new_baf_red(x,y,fmath.random_fixedpoint(0fx,fmath.tau()),15fx,-1)
  end
  if time %15 == 0 then
    local x, y = random_position()
    pewpew.new_baf_blue(x,y,fmath.random_fixedpoint(0fx,fmath.tau()),15fx,-1)
  end
end)
elseif random_level == 2 then
pewpew.configure_player_hud(0, {top_left_line = "#ff7000ffMothership"})
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
  if time % 10 == 0 then
    local x, y = random_position()
    local angle = fmath.random_fixedpoint(0fx, fmath.tau())
    pewpew.new_mothership(x, y, pewpew.MothershipType.FIVE_CORNERS, angle)
  end
end)
elseif random_level == 3 then
pewpew.configure_player_hud(0, {top_left_line = "#ffcb00ffInertiac"})
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
  if time % 200 == 0 then
    for count = 1, 15 do
      local x, y = random_position()
      pewpew.new_inertiac(x, y, 10fx/20fx, fmath.random_fixedpoint(0fx,fmath.tau()))
    end
  end 
end)
elseif random_level == 4 then
pewpew.configure_player_hud(0, {top_left_line = "#ff0000ffBaf red"})
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
  if time %20 == 0 then
    local x, y = random_position()
    pewpew.new_baf_red(x,y,fmath.random_fixedpoint(0fx,fmath.tau()),15fx,-1)
  end
end)
elseif random_level == 5 then
pewpew.configure_player_hud(0, {top_left_line = "#ff0000aaMothership 2"})
pewpew.configure_player(0, {shield = 256, camera_distance = -100fx})
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
  if time % 100 == 0 then
    local angle = fmath.random_fixedpoint(0fx, fmath.tau())
    pewpew.new_super_mothership(5fx, 5fx, pewpew.MothershipType.THREE_CORNERS, angle)
    pewpew.new_super_mothership(5fx, 5fx, pewpew.MothershipType.SIX_CORNERS, angle)
    pewpew.new_super_mothership(5fx, 5fx, pewpew.MothershipType.FIVE_CORNERS, angle)
    pewpew.new_super_mothership(5fx, 5fx, pewpew.MothershipType.SEVEN_CORNERS, angle)
    pewpew.new_super_mothership(5fx, 5fx, pewpew.MothershipType.FOUR_CORNERS, angle)
  end
end)
elseif random_level == 6 then
pewpew.configure_player_hud(0, {top_left_line = "UFO attack"})
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
  if time % 60 == 0 then
    local x, y = random_position()
    local ufo=pewpew.new_ufo(x, y, 5fx) pewpew.ufo_set_enable_collisions_with_walls(ufo, true)
  end
end)
elseif random_level == 7 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
elseif random_level == 8 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
elseif random_level == 9 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
elseif random_level == 10 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
elseif random_level == 11 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
elseif random_level == 12 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
elseif random_level == 13 then
pewpew.configure_player_hud(0, {top_left_line = "Level not found"})
end