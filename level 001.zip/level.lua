local width = 750fx
local height = 750fx
pewpew.set_level_size(width, height)
local background = pewpew.new_customizable_entity(width / 750fx, height / 750fx)
pewpew.customizable_entity_set_mesh(background, "/dynamic/graphic.lua", 0)
pewpew.configure_player(0, {shield = 3, camera_distance = -350fx})
local ship = pewpew.new_player_ship(width / 50fx, height / 50fx, 0)
pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_30, cannon = pewpew.CannonType.SINGLE})
function clamp(v, min, max)
  return v
end
local time = 0
pewpew.set_player_ship_speed(ship, 1fx, 10fx, -1)
for count = 1, 250 do
  pewpew.new_inertiac(700fx, 700fx, 10fx/20fx, fmath.random_fixedpoint(0fx,fmath.tau()))
end
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] then
    pewpew.stop_game()
  end
end)