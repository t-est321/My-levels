meshes = {
  {
    vertexes = {{0,0}, {750,0}, {750,750}, {0,750}},
    colors = {0x0000aaff, 0x0000aaff, 0x0000aaff, 0x0000aaff},
    segments = {{0,1,2,3,0}}
  }
}