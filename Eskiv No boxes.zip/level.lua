local width = 750fx
local height = 750fx
pewpew.set_level_size(width, height)
local ground = pewpew.new_customizable_entity(width / 750fx, height / 750fx)
pewpew.customizable_entity_set_mesh(ground, "/dynamic/background.lua", 0)
local function random_position()
  return fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height)
end
local bg = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(bg, "/dynamic/level_graphics.lua", 0)
pewpew.configure_player(0, {shield = 5, camera_distance = -400fx, camera_rotation_x_axis = fmath.tau() / -55fx})
local ship = pewpew.new_player_ship(width / 50fx, height / 50fx, 0)
pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_5, cannon = pewpew.CannonType.SINGLE})
function clamp(v, min, max)
  return v
end
local counter = pewpew.new_customizable_entity(width / 8fx, height / -12fx)
pewpew.customizable_entity_set_mesh_scale(counter,3fx)
local time = 0
local count = 180
pewpew.add_update_callback(function()
  time = time + 1
  pewpew.increase_score_of_player(0, 1)
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] == true then
    pewpew.stop_game()
  end
  if time % 30 == 0 then
    local x, y = random_position()
    pewpew.new_rolling_sphere(x, y, fmath.random_fixedpoint(0fx,fmath.tau()), 1fx)
    count = count - 1
  end
  if time % 1500 == 0 then
    local x, y = random_position()
    local rx, ry = random_position()
    local ufo=pewpew.new_ufo(rx, ry, 1fx) pewpew.ufo_set_enable_collisions_with_walls(ufo, true)
  end
  if pewpew.entity_get_is_alive(counter) then
    if count >= 0 then
      pewpew.customizable_entity_set_string(counter, "#aa55ddff" .. count)
    end
    if count == -1 then
      local shield_count = pewpew.get_player_configuration(0).shield
      pewpew.increase_score_of_player(0,shield_count*100)
      pewpew.entity_destroy(counter)
      pewpew.stop_game()
    end
  end
end)